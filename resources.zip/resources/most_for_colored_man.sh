#!/bin/bash

# install `most` pagers and sets as default for man paging

sudo apt install most
export MANPAGER='most'
