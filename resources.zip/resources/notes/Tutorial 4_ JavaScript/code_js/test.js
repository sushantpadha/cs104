// let x = 10;
// console.log(x);

// x += 5;
// console.log(x);

// console.log((x>12) ? "Yes" : "No");

// y = 0 + x;
// z = "0" + x;
// console.log(y);
// console.log(z);

// let uniq = Symbol('id')
// console.log(uniq)

// console.log(y==z)

// function First(a, b)
// {
// 	console.log("This code is executed only after calling" + a + b);
// 	return 0;
// }

// console.log("Calling function");

// First(" ",z)

// let e = First;
// e(1,2)

// a1 = [1,2,3,4,5]

// console.log(a1)
// a1.push(6)
// console.log(a1[5]+1)

// a2 = a1.map(
// 	(x) => {
// 		return 1;
// 	}
// );
// a1.forEach((element) => {
// 	console.log("Hello" + element);
// });

// a3= a1.filter(
// 	(e, id) => { return id/e < 0.7; }
// )
// console.log(a3);

// a4 = a3.reduce((prev, el, idx) => {return prev + el;})
// console.log(a4);

// try {
// 	var obj = {
// 		name: "",
// 		age: 12,

// 		getName: function () {
// 			return this.name;
// 		},

// 	}

// 	console.log(obj)
// 	obj.name = "Kritin"
// 	console.log(obj.getName())

// }
// catch (e) {
// 	console.log("Error: ", e);
// }

// class Person {
// 	static x = 0;
// 	constructor(name, age) {
// 		this.name = name;
// 		this.age = age;
// 	}

// 	get getname()
// 	{
// 		Person.x += 1;
// 		return this.name;
// 	}

// 	set setname(n)
// 	{
// 		this.name = n;
// 	}

// 	func()
// 	{
// 		return `${this.name} - ${this.age}`
// 		// return "This is " + this.name + " aged " + this.age;
// 	}
// }

// let p = new Person("A", 12);
// const q = new Person("B", 34);
// //q=p not allowed
// console.log(q.getname)
// console.log(p.getname)
// console.log(Person.x)


// for (const key in p) {
// 	console.log(key + ": " + p[key]);
// }

// let ptags = document.getElementById("1");
// console.log(ptags);




