#ifndef __TIMEUTIL_H__
#define __TIMEUTIL_H__

#include <sys/time.h>

double now(struct timeval start);

#endif
